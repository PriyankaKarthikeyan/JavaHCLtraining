package com.hcl.model;

public class User {

}
